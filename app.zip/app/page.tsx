"use client";

import React, { useState, useEffect } from "react";
import { read, utils } from "xlsx";
import { useRouter } from "next/navigation";
import { useRuleStore } from "./store/ruleStore";

export default function HomePage() {
  const [fileName, setFileName] = useState("");
  const setRules = useRuleStore((state) => state.setRules); 
  const router = useRouter();
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true); // Set to true when the component has mounted
  }, []);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    setFileName(file.name);
    const reader = new FileReader();

    reader.onload = (e) => {
      const binaryStr = e.target.result;
      const workbook = read(binaryStr, { type: "binary" });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      const sheetData = utils.sheet_to_json(sheet, { header: 1 });

      // Skip the first 6 rows and parse the rule data
      const ruleData = sheetData.slice(6);

      const parsedRules = ruleData
        .filter((row) => row.length > 0) 
        .map((row, index) => ({
          id: index + 1, 
          name: row[0], 
          maxTreeTraversal: row[1], 
          substanceCodes: row[2] ? row[2].split(",").map(code => code.trim().replace(/\"/g, '')) : [], 
          parentCode: row[4] ? row[4].replace(/\"/g, '') : "", 
        }));

      setRules(parsedRules);

      if (isMounted) {
        router.push("/rules"); // Only redirect if the component has mounted
      }
    };

    reader.readAsBinaryString(file);
  };

  return (
    <div>
      <input type="file" onChange={handleFileUpload} accept=".xlsx, .xls" />
      {fileName && <p>Loaded file: {fileName}</p>}
    </div>
  );
}