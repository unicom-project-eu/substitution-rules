"use client"; // Mark this component as a client component

import RuleForm from '../../components/RuleForm';
import { Typography } from '@mui/material';

export default function NewRulePage() {
  const handleSaveRule = (newRule: any) => {
    // Handle rule saving (e.g., sending to backend)
    console.log('Rule Saved:', newRule);
  };

  return (
    <div>
      <Typography variant="h4" component="h2" gutterBottom>
        Create New Rule
      </Typography>
      <RuleForm onSave={handleSaveRule} />
    </div>
  );
}
