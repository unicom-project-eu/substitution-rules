// app/rules/page.tsx
import RuleList from '../components/RuleList';
import { Typography } from '@mui/material';

export default function RulesPage() {
  return (
    <div>
      <Typography variant="h4" component="h2" gutterBottom>
        Rules List
      </Typography>
      <RuleList />
    </div>
  );
}
