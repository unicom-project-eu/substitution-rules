'use client';
import React, { useEffect, useState } from 'react';
import { fetchRules } from '../../services/droolService'; // Adjust the import to match your file structure
import { Table, TableHead, TableBody, TableRow, TableCell, CircularProgress, Typography } from '@mui/material';

const RulesPage = () => {
  const [rules, setRules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function loadRules() {
      try {
        const fetchedRules = await fetchRules();
        setRules(fetchedRules);
      } catch (error) {
        setError('Failed to load rules. Please check the console for more details.');
        console.error('Error fetching rules:', error);
      } finally {
        setLoading(false);
      }
    }

    loadRules();
  }, []);

  if (loading) {
    return <CircularProgress />;
  }

  if (error) {
    return <Typography color="error">{error}</Typography>;
  }

  return (
    <div>
      <Typography variant="h4" gutterBottom>Rules</Typography>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Rule Name</TableCell>
            <TableCell>Rule Content</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rules.map((rule, index) => (
            <TableRow key={index}>
              <TableCell>{rule.name}</TableCell>
              <TableCell>{rule.content}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default RulesPage;