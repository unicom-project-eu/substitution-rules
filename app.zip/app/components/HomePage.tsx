"use client";

import React, { useState } from "react";
import { useRouter } from "next/router";

export default function HomePage() {
  const router = useRouter();  // Ensure this is in a Client Component
  const [fileName, setFileName] = useState("");

  const handleFileUpload = (event) => {
    // Handle the file upload logic here
    router.push("/rules");
  };

  return (
    <div>
      <input type="file" onChange={handleFileUpload} />
      {fileName && <p>Loaded file: {fileName}</p>}
    </div>
  );
}