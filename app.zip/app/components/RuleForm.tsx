import React, { useState, useEffect } from "react";
import {
  TextField,
  Button,
  Typography,
  Card,
  CardContent,
  Autocomplete,
  Checkbox,
} from "@mui/material";
import { useRouter } from "next/navigation";
import { fetchAndGroupSubstances } from "../services/fhirService";
import { useRuleStore } from "../store/ruleStore";

export default function RuleForm({ rule, onSave }) {
  const [ruleName, setRuleName] = useState(rule ? rule.name : "");
  const [groupedSubstances, setGroupedSubstances] = useState({});
  const [masterSubstance, setMasterSubstance] = useState(rule ? rule.masterSubstance : null);
  const [substitutes, setSubstitutes] = useState(rule ? rule.substitutes : []);
  const [possibleSubstitutes, setPossibleSubstitutes] = useState([]);
  const [parentSubstance, setParentSubstance] = useState(rule ? rule.parentSubstance : null);
  const [ruleNameError, setRuleNameError] = useState(false);

  const addRule = useRuleStore((state) => state.addRule);
  const updateRule = useRuleStore((state) => state.updateRule);
  const router = useRouter();

  useEffect(() => {
    fetchSubstances();
  }, []);

  const fetchSubstances = async () => {
    try {
      const substances = await fetchAndGroupSubstances();
      setGroupedSubstances(substances);
    } catch (error) {
      console.error("Error fetching substances:", error);
    }
  };

  const handleSave = () => {
    if (!ruleName.trim()) {
      setRuleNameError(true);
      return;
    } else {
      setRuleNameError(false);
    }

    if (!masterSubstance || !parentSubstance) {
      alert("Please select a master substance and a parent substance.");
      return;
    }

    const newRule = {
      id: rule ? rule.id : Date.now(),
      name: ruleName.trim(),
      condition: `Substance equals ${masterSubstance.label}`,
      action: `List of possible substitutes: ${substitutes.map((sub) => sub.display).join(", ")}`,
      parentCode: parentSubstance.value,
    };

    if (rule) {
      updateRule(newRule); // If editing, update the rule
    } else {
      addRule(newRule); // If creating, add the rule
    }

    onSave(newRule);
    router.push("/rules");
  };

  return (
    <div className="container mx-auto p-4">
      <Typography variant="h4" className="text-center text-gray-800 mb-6">
        {rule ? "Edit Rule" : "Create New Rule"}
      </Typography>

      {/* Rest of your form structure goes here */}

      <div className="text-center">
        <Button
          variant="contained"
          color="primary"
          onClick={handleSave}
          className="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded"
        >
          Save Rule
        </Button>
      </div>
    </div>
  );
}