"use client";

import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Typography,
} from "@mui/material";
import { useRuleStore } from "../store/ruleStore";
import RuleForm from "./RuleForm"; // Import the RuleForm component

export default function RuleList() {
  const { rules } = useRuleStore(); // Get rules from Zustand
  const [selectedRule, setSelectedRule] = useState(null); // Track the selected rule for editing

  const handleEditClick = (rule) => {
    setSelectedRule(rule); // Set the selected rule for editing
  };

  const handleFormSave = (updatedRule) => {
    setSelectedRule(null); // Reset the selected rule after saving
  };

  return (
    <div>
      <TableContainer component={Paper}>
        <Typography variant="h5" component="h2" gutterBottom sx={{ padding: 2 }}>
          Rule List
        </Typography>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Rule Name</TableCell>
              <TableCell>Condition</TableCell>
              <TableCell>Action</TableCell>
              <TableCell>Parent Code</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rules.map((rule) => (
              <TableRow key={rule.id}>
                <TableCell>{rule.name}</TableCell>
                <TableCell>{rule.condition}</TableCell>
                <TableCell>{rule.action}</TableCell>
                <TableCell>{rule.parentCode}</TableCell>
                <TableCell align="right">
                  <Button onClick={() => handleEditClick(rule)} variant="outlined" color="primary">
                    Edit
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {selectedRule && (
        <RuleForm
          rule={selectedRule} // Pass the selected rule to the form
          onSave={handleFormSave}
        />
      )}
    </div>
  );
}