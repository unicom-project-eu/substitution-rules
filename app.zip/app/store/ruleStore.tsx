import create from 'zustand';

interface Rule {
  id: number;
  name: string;
  condition: string;
  action: string;
}

interface RuleStore {
  rules: Rule[];
  setRules: (rules: Rule[]) => void;
  updateRule: (updatedRule: Rule) => void;
  addRule: (rule: Rule) => void;
}

export const useRuleStore = create<RuleStore>((set) => ({
  rules: [],
  setRules: (rules) => set({ rules }),
  addRule: (rule) => set((state) => ({ rules: [...state.rules, rule] })),
  updateRule: (updatedRule) =>
    set((state) => ({
      rules: state.rules.map((rule) =>
        rule.id === updatedRule.id ? updatedRule : rule
      ),
    })),
}));