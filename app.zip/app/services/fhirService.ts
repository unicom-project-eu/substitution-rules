import axios from "axios";

// Function to fetch the CodeSystem containing substances and group them alphabetically
export async function fetchAndGroupSubstances() {
  try {
    const response = await axios.get("https://jpa.unicom.datawizard.it/fhir/CodeSystem/substance-sms-cs");
    const concepts = response.data.concept || [];

    // Group substances by their base name (using first few characters as a heuristic)
    const groupedSubstances: { [group: string]: { code: string, display: string }[] } = {};

    concepts.forEach((concept: { code: string; display: string }) => {
      // Apply camel case formatting to display name
      const camelCaseDisplay = toCamelCase(concept.display);
      const baseName = getBaseName(camelCaseDisplay);
      
      if (!groupedSubstances[baseName]) {
        groupedSubstances[baseName] = [];
      }
      groupedSubstances[baseName].push({ code: concept.code, display: camelCaseDisplay });
    });

    return groupedSubstances;
  } catch (error) {
    console.error("Error fetching CodeSystem:", error);
    return {};
  }
}

// Helper function to format display names to camel case
function toCamelCase(text: string) {
  return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
}

// Helper function to extract the base name for grouping (e.g., first few characters)
function getBaseName(displayName: string) {
  // Grouping by the first word, assuming that base names are the first word (e.g., "Amlodipine")
  const baseName = displayName.split(" ")[0].toLowerCase(); 
  return baseName;
}
